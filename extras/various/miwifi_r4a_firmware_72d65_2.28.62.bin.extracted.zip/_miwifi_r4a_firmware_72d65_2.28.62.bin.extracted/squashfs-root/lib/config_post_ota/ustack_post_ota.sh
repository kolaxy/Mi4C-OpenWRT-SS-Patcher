#!/bin/sh
# Copyright (C) 2015 Xiaomi
. /lib/functions.sh

