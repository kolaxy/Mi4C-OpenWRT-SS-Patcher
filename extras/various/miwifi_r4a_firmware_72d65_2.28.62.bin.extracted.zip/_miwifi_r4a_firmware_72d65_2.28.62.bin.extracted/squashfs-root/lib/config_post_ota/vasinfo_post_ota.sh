#!/bin/sh
# Copyright (C) 2015 Xiaomi

/usr/sbin/vasinfo_fw.sh post_ota

