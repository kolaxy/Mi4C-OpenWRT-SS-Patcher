#!/bin/sh

CONFIG_ZIP_FILE_PATH="/tmp/config.zip"
CONFIG_FILE_PATH="/etc/config/"

zip -r $CONFIG_ZIP_FILE_PATH $CONFIG_FILE_PATH







