#!/bin/sh
logger stat_points_instant register_first_time=1
logger stat_points_none web_reset_click_times=1
logger stat_points_privacy privacy_test_click_times=1
