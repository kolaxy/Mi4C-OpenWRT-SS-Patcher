#!/bin/sh
> /tmp/stat_points_rom.log
> /tmp/stat_points_web.log
> /tmp/stat_points_privacy.log
rm /tmp/stat_points.json.gz 2>/dev/null
