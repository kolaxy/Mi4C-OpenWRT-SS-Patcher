#!/bin/sh

root_path=$1

chroot $root_path $2 $3

