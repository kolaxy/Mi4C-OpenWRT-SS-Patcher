#!/bin/sh
# Copyright (C) 2016 Xiaomi
. /usr/sbin/wifishare.sh
