#!/bin/sh
/usr/sbin/datacenterClient -h localhost -p 9090 -i "{\"api\":101}"
