#!/bin/sh /etc/rc.common
# Copyright (C) 2014-2014 jiayuehua

START=51
STOP=
SOURCE_PATH=/usr/share/datacenter/appdata
DEST_PATH=/userdisk/appdata/

. /usr/share/datacenter/cp_preinstall_plugins_impl.sh

