
#!/bin/sh

/usr/bin/lua /usr/sbin/controller.lua
